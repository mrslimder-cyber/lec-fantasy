module.exports = { output: 'export' };
